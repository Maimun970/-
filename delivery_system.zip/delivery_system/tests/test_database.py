import pytest
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database import init_db, add_customer, get_customers, delete_customer, add_order, get_orders
from models import OrderItem

@pytest.fixture(autouse=True)
def setup_db(monkeypatch):
    monkeypatch.setattr("database.DB_PATH", "data/test_delivery.db")
    init_db()
    yield
    if os.path.exists("data/test_delivery.db"):
        os.remove("data/test_delivery.db")

def test_add_and_get_customer():
    cid = add_customer("Иван", "+79000000000", "Москва")
    customers = get_customers()
    assert len(customers) == 1
    assert customers[0].name == "Иван"

def test_delete_customer_with_orders():
    cid = add_customer("Петр", "+79000000001", "Спб")
    add_order(cid, "2026-06-15", "новый", 100.0, [OrderItem(None, None, "Пицца", 1, 100.0)])
    result = delete_customer(cid)
    assert result is False
    assert len(get_customers()) == 1

def test_delete_customer_without_orders():
    cid = add_customer("Анна", "+79000000002", "Казань")
    result = delete_customer(cid)
    assert result is True
    assert len(get_customers()) == 0

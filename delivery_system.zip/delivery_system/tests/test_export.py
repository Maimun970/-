import pytest
import os
import sys
import json
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database import init_db, add_customer, add_order
from models import OrderItem
from data_export import export_to_json, import_from_json

@pytest.fixture(autouse=True)
def setup_db(monkeypatch):
    monkeypatch.setattr("database.DB_PATH", "data/test_delivery.db")
    init_db()
    yield
    if os.path.exists("data/test_delivery.db"):
        os.remove("data/test_delivery.db")
    if os.path.exists("test_export.json"):
        os.remove("test_export.json")

def test_json_export_import():
    cid = add_customer("Экспорт Тест", "123", "Addr")
    add_order(cid, "2026-06-15", "новый", 500.0, [OrderItem(None, None, "Тест", 1, 500.0)])
    
    export_to_json("test_export.json")
    assert os.path.exists("test_export.json")
    
    with open("test_export.json", "r") as f:
        data = json.load(f)
    assert len(data) == 1
    assert data[0]["total"] == 500.0

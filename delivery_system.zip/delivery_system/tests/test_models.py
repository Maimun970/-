import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from models import Customer, Order, OrderItem

def test_customer_creation():
    c = Customer(id=1, name="Test", phone="123", address="Addr")
    assert c.name == "Test"

def test_order_creation():
    item = OrderItem(id=1, order_id=1, product_name="Burger", quantity=2, price=150.0)
    o = Order(id=1, customer_id=1, order_date="2026-06-15", status="новый", total=300.0, items=[item])
    assert o.total == 300.0
    assert len(o.items) == 1
